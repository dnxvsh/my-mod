package com.elytrarealism;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public final class ElytraConfig {
    public static final Common COMMON;
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        Pair<Common, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ForgeConfigSpec> cl = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = cl.getLeft();
        CLIENT_SPEC = cl.getRight();
    }

    private ElytraConfig() {}

    /** Physics settings (elytrarealism-common.toml). */
    public static final class Common {
        public final ForgeConfigSpec.BooleanValue enabled, banking, wind, turbulence, thermals;
        public final ForgeConfigSpec.DoubleValue aeroStrength, stallAngle, maxG, maxSpeed,
                airDensityHeight, windStrength, impactDamage;

        Common(ForgeConfigSpec.Builder b) {
            b.push("physics");
            enabled = b.comment("Master switch. false = vanilla elytra physics.")
                    .define("enabled", true);
            aeroStrength = b.comment("Wing efficiency. Higher = more lift and drag, lower stall speed.")
                    .defineInRange("aeroStrength", 0.11, 0.02, 0.3);
            stallAngle = b.comment("Angle of attack (degrees) where the wing stalls.")
                    .defineInRange("stallAngle", 17.0, 8.0, 35.0);
            maxG = b.comment("Structural G limit of the wings (lift is clipped above this).")
                    .defineInRange("maxG", 8.0, 2.0, 20.0);
            maxSpeed = b.comment("Soft speed limit in blocks/tick (extra drag above it). 4.0 = 80 m/s.")
                    .defineInRange("maxSpeed", 4.0, 1.5, 10.0);
            airDensityHeight = b.comment("Scale height for thinner air at altitude. 0 = constant density.")
                    .defineInRange("airDensityHeight", 600.0, 0.0, 5000.0);
            impactDamage = b.comment("Multiplier for damage when hitting a wall.")
                    .defineInRange("impactDamage", 1.0, 0.0, 5.0);
            banking = b.comment("Banked turns: lift tilts into the turn based on your turn rate.")
                    .define("banking", true);
            b.pop();

            b.push("environment");
            wind = b.comment("Steady wind that drifts you (stronger in storms and at altitude).")
                    .define("wind", true);
            windStrength = b.comment("Wind strength multiplier.")
                    .defineInRange("windStrength", 1.0, 0.0, 5.0);
            turbulence = b.comment("Random gusts, stronger in rain/thunder and near the ground.")
                    .define("turbulence", true);
            thermals = b.comment("Rising air above campfires, lava, magma, fire and hot biomes by day.")
                    .define("thermals", true);
            b.pop();
        }
    }

    /** Client-only visuals (elytrarealism-client.toml). */
    public static final class Client {
        public final ForgeConfigSpec.BooleanValue showHud, cameraRoll, cameraShake, dynamicFov,
                gVision, vaporTrails, stallWarning;
        public final ForgeConfigSpec.DoubleValue rollFactor, stallNoseDrop;

        Client(ForgeConfigSpec.Builder b) {
            b.push("visuals");
            showHud = b.define("showHud", true);
            cameraRoll = b.comment("Roll the camera when banking.").define("cameraRoll", true);
            rollFactor = b.comment("Camera roll multiplier. Negative flips the direction.")
                    .defineInRange("rollFactor", 0.7, -2.0, 2.0);
            cameraShake = b.comment("Buffeting at stall, very high speed and high G.")
                    .define("cameraShake", true);
            dynamicFov = b.comment("Wider field of view at high speed.").define("dynamicFov", true);
            gVision = b.comment("Blackout / redout vignette at high positive / negative G.")
                    .define("gVision", true);
            vaporTrails = b.comment("Condensation trails from the wingtips at high G or speed.")
                    .define("vaporTrails", true);
            stallWarning = b.comment("Beeping stall warning.").define("stallWarning", true);
            stallNoseDrop = b.comment("Degrees per tick the nose drops in a deep stall. 0 = off.")
                    .defineInRange("stallNoseDrop", 1.5, 0.0, 5.0);
            b.pop();
        }
    }
}
