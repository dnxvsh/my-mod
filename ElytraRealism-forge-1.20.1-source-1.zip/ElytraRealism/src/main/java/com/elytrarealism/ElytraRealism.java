package com.elytrarealism;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(ElytraRealism.MODID)
public class ElytraRealism {
    public static final String MODID = "elytrarealism";

    public ElytraRealism() {
        ModLoadingContext ctx = ModLoadingContext.get();
        ctx.registerConfig(ModConfig.Type.COMMON, ElytraConfig.COMMON_SPEC);
        ctx.registerConfig(ModConfig.Type.CLIENT, ElytraConfig.CLIENT_SPEC);
    }
}
