package com.elytrarealism;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Air density, wind, gusts and thermals. All values are in blocks/tick. */
public final class Environment {
    private Environment() {}

    public static double airDensity(double y, double scaleHeight) {
        if (scaleHeight <= 0.0) return 1.0;
        return Mth.clamp(Math.exp(-(y - 64.0) / scaleHeight), 0.5, 1.4);
    }

    public static double heightAboveGround(Level level, Entity e, double max) {
        Vec3 from = e.position();
        Vec3 to = from.add(0.0, -max, 0.0);
        BlockHitResult hit = level.clip(new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
        return hit.getType() == HitResult.Type.MISS ? max : from.y - hit.getLocation().y;
    }

    /** Cheap smooth pseudo-noise in [-1, 1]. */
    public static double noise(double a, double b, double c) {
        return (Math.sin(a * 1.7 + Math.sin(b * 2.3))
                + Math.sin(b * 1.3 + Math.sin(c * 1.9))
                + Math.sin(c * 1.1 + Math.sin(a * 2.1))) / 3.0;
    }

    /** Velocity of the air mass at the player's position (also updates thermal state). */
    public static Vec3 wind(Level level, Player p, FlightState st, long t) {
        ElytraConfig.Common cfg = ElytraConfig.COMMON;
        double x = p.getX(), y = p.getY(), z = p.getZ();
        double wx = 0.0, wy = 0.0, wz = 0.0;
        double weather = level.isThundering() ? 2.5 : (level.isRaining() ? 1.6 : 1.0);

        if (cfg.wind.get()) {
            double dir = Math.PI * 2.0 * (0.5 + 0.5 * Math.sin(t * 0.00009 + 0.7))
                    + Math.sin(t * 0.00031) * 0.6;
            double speed = 0.08 * cfg.windStrength.get() * weather
                    * (1.0 + Math.max(0.0, y - 64.0) / 160.0);
            speed *= 0.7 + 0.3 * Math.sin(t * 0.0009 + x * 0.002);
            wx = Math.cos(dir) * speed;
            wz = Math.sin(dir) * speed;
        }

        if (cfg.turbulence.get()) {
            double near = Mth.clamp(1.0 - st.heightAgl / 24.0, 0.0, 1.0);
            double k = 0.012 * weather * weather * (1.0 + 2.0 * near);
            double tt = t * 0.07;
            wx += noise(x * 0.06 + tt, y * 0.08, z * 0.06 + 17.3) * k;
            wy += noise(x * 0.07 + 5.1, y * 0.06 + tt * 1.3, z * 0.07) * k * 0.8;
            wz += noise(x * 0.06 + 41.7, y * 0.08 + tt * 0.8, z * 0.06) * k;
        }

        if (cfg.thermals.get()) {
            if (t - st.thermalScan >= 4) {
                st.thermalScan = t;
                st.thermalTarget = scanThermals(level, p, st.heightAgl);
            }
            st.thermal += (st.thermalTarget - st.thermal) * 0.2;
            wy += st.thermal;
        } else {
            st.thermal = 0.0;
        }
        return new Vec3(wx, wy, wz);
    }

    private static double scanThermals(Level level, Player p, double agl) {
        BlockPos origin = p.blockPosition();
        double best = 0.0;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = 0; dy <= 32; dy++) {
                    int by = origin.getY() - dy;
                    if (by < level.getMinBuildHeight()) break;
                    m.set(origin.getX() + dx, by, origin.getZ() + dz);
                    BlockState s = level.getBlockState(m);
                    double heat = heat(s);
                    if (heat > 0.0) {
                        double lift = heat * (1.0 - dy / 33.0) * (dx == 0 && dz == 0 ? 1.0 : 0.6);
                        best = Math.max(best, lift);
                        break;
                    }
                    if (!s.isAir() && s.blocksMotion()) break;
                }
            }
        }

        // Sun-heated ground in hot biomes: patchy, slowly drifting thermals by day.
        if (level.isDay() && !level.isRaining() && agl > 2.0 && agl < 80.0) {
            float temp = level.getBiome(origin).value().getBaseTemperature();
            if (temp >= 1.5F) {
                double n = noise(p.getX() * 0.02 + 3.1, 0.0, p.getZ() * 0.02 + level.getGameTime() * 0.0004);
                if (n > 0.1) {
                    best = Math.max(best, 0.09 * (n - 0.1) / 0.9 * (1.0 - agl / 90.0));
                }
            }
        }
        return best;
    }

    private static double heat(BlockState s) {
        if (s.getFluidState().is(FluidTags.LAVA)) return 0.22;
        if (s.is(Blocks.MAGMA_BLOCK)) return 0.10;
        if (s.is(BlockTags.FIRE)) return 0.14;
        if (s.is(BlockTags.CAMPFIRES) && s.hasProperty(BlockStateProperties.LIT)
                && s.getValue(BlockStateProperties.LIT)) return 0.18;
        return 0.0;
    }
}
