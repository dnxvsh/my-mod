package com.elytrarealism.client;

import com.elytrarealism.ElytraConfig;
import com.elytrarealism.FlightState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import java.util.Locale;

/** Flight instruments + blackout/redout vignette. */
public final class FlightHud {
    private FlightHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.options.hideGui || !p.isFallFlying()) return;
        FlightState st = FlightState.peek(p);
        if (st == null || !st.isActive(mc.level.getGameTime())) return;

        ElytraConfig.Client cfg = ElytraConfig.CLIENT;

        // G-force vision
        if (cfg.gVision.get()) {
            double gl = st.gSmooth;
            if (gl > 4.5) {
                vignette(g, width, height, (float) Mth.clamp((gl - 4.5) / 4.0, 0.0, 0.92), 0x000000);
            } else if (gl < -1.5) {
                vignette(g, width, height, (float) Mth.clamp((-gl - 1.5) / 2.5, 0.0, 0.7), 0xAA0000);
            }
        }

        if (!cfg.showHud.get()) return;

        Vec3 v = p.getDeltaMovement();
        double kmh = v.length() * 72.0;          // blocks/tick -> km/h
        double vs = v.y * 20.0;                  // m/s
        String agl = st.heightAgl >= 63.5 ? ">64 m" : String.format(Locale.ROOT, "%.0f m", st.heightAgl);

        String[] lines = {
                String.format(Locale.ROOT, "SPD  %.0f km/h", kmh),
                String.format(Locale.ROOT, "ALT  %.0f m", p.getY()),
                "AGL  " + agl,
                String.format(Locale.ROOT, "V/S  %+.1f m/s", vs),
                String.format(Locale.ROOT, "G    %.1f", st.gSmooth),
                String.format(Locale.ROOT, "AoA  %.0f\u00B0", st.aoaDeg),
                String.format(Locale.ROOT, "AIR  %+.1f m/s", st.thermal * 20.0)
        };

        int color = st.stalled ? 0xFF5555 : (st.stallMargin > 0.85 && st.aoaDeg > 0 ? 0xFFFF55 : 0x55FF55);
        int x = 8;
        int y = height / 2 - lines.length * 5;
        for (String line : lines) {
            g.drawString(mc.font, line, x, y, color, true);
            y += 10;
        }

        if (st.stalled && (mc.level.getGameTime() / 4) % 2 == 0) {
            g.drawCenteredString(mc.font, "STALL", width / 2, height / 2 + 30, 0xFF3333);
        }
    }

    private static void vignette(GuiGraphics g, int w, int h, float a, int rgb) {
        int solid = ((int) (a * 255.0F) & 0xFF) << 24 | rgb;
        int clear = rgb;
        int tint = ((int) (a * 0.35F * 255.0F) & 0xFF) << 24 | rgb;
        g.fill(0, 0, w, h, tint);
        g.fillGradient(0, 0, w, h / 3, solid, clear);
        g.fillGradient(0, h - h / 3, w, h, clear, solid);
    }
}
