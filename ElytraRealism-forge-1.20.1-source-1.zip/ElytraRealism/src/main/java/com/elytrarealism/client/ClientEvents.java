package com.elytrarealism.client;

import com.elytrarealism.ElytraConfig;
import com.elytrarealism.ElytraRealism;
import com.elytrarealism.FlightState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Camera roll, shake, FOV, wingtip vapor, stall nose-drop and stall warning. */
@Mod.EventBusSubscriber(modid = ElytraRealism.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    private static FlightState activeState(Minecraft mc, Player p) {
        if (p == null || mc.level == null || !p.isFallFlying()) return null;
        FlightState st = FlightState.peek(p);
        return (st != null && st.isActive(mc.level.getGameTime())) ? st : null;
    }

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        FlightState st = activeState(mc, p);
        if (st == null) return;

        ElytraConfig.Client cfg = ElytraConfig.CLIENT;
        float pt = (float) e.getPartialTick();
        float roll = 0.0F;
        if (cfg.cameraRoll.get()) {
            double bank = Mth.lerp(pt, st.prevBank, st.bank);
            roll = (float) (Math.toDegrees(bank) * cfg.rollFactor.get());
        }

        double shake = 0.0;
        if (cfg.cameraShake.get()) {
            if (st.stalled) shake += 0.9;
            shake += Mth.clamp((p.getDeltaMovement().length() - 2.2) * 0.35, 0.0, 1.2);
            shake += Mth.clamp((Math.abs(st.gSmooth) - 5.0) * 0.15, 0.0, 1.0);
        }
        if (shake > 0.0) {
            double tm = mc.level.getGameTime() + pt;
            e.setPitch(e.getPitch() + (float) (Math.sin(tm * 2.9) * shake * 0.5));
            e.setYaw(e.getYaw() + (float) (Math.cos(tm * 3.7) * shake * 0.5));
            roll += (float) (Math.sin(tm * 4.3) * shake * 0.8);
        }
        e.setRoll(e.getRoll() + roll);
    }

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent e) {
        if (!ElytraConfig.CLIENT.dynamicFov.get()) return;
        Player p = e.getPlayer();
        if (p == null || !p.isFallFlying()) return;
        double sp = p.getDeltaMovement().length();
        float extra = (float) Mth.clamp((sp - 1.0) / 3.0, 0.0, 1.0) * 0.30F;
        e.setNewFovModifier(e.getNewFovModifier() * (1.0F + extra));
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (mc.isPaused()) return;
        FlightState st = activeState(mc, p);
        if (st == null) return;

        ElytraConfig.Client cfg = ElytraConfig.CLIENT;
        double speed = p.getDeltaMovement().length();

        // Deep stall: the nose drops by itself (like a real aircraft).
        if (st.stalled && st.aoaDeg > 0.0 && speed < 1.6 && cfg.stallNoseDrop.get() > 0.0) {
            double excess = Mth.clamp(st.stallMargin - 1.0, 0.0, 0.5) * 2.0;
            float drop = (float) (cfg.stallNoseDrop.get() * excess);
            p.setXRot(Mth.clamp(p.getXRot() + drop, -90.0F, 90.0F));
        }

        // Condensation trails at the wingtips.
        if (cfg.vaporTrails.get() && (st.gSmooth > 4.0 || st.gSmooth < -2.0 || speed > 2.6)) {
            Vec3 c = p.position().add(0.0, p.getBbHeight() * 0.55, 0.0).subtract(p.getLookAngle().scale(0.4));
            for (int s = -1; s <= 1; s += 2) {
                Vec3 tip = c.add(st.right.scale(0.9 * s));
                mc.level.addParticle(ParticleTypes.CLOUD, tip.x, tip.y, tip.z, 0.0, 0.0, 0.0);
            }
        }

        // Stall warning beeper.
        if (cfg.stallWarning.get() && st.aoaDeg > 0.0 && st.stallMargin > 0.92
                && mc.level.getGameTime() % 5 == 0) {
            mc.level.playLocalSound(p.getX(), p.getY(), p.getZ(), SoundEvents.DISPENSER_FAIL,
                    SoundSource.PLAYERS, 0.4F, 2.0F, false);
        }
    }
}
