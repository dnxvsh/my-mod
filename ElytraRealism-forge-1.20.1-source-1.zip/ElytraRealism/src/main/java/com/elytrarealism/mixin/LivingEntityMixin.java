package com.elytrarealism.mixin;

import com.elytrarealism.ElytraPhysics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {

    @Shadow
    public abstract void calculateEntityAnimation(boolean flying);

    /** Replaces vanilla fall-flying movement with the aerodynamic model. */
    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void elytrarealism$travel(Vec3 input, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (ElytraPhysics.shouldHandle(self)) {
            ElytraPhysics.travel((Player) self);
            this.calculateEntityAnimation(false);
            ci.cancel();
        }
    }
}
