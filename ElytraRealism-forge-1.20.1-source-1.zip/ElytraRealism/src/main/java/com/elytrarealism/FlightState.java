package com.elytrarealism;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/** Per-player flight data that must persist between ticks (also read by the HUD/camera). */
public final class FlightState {
    // Entity.equals() compares ids, and client/server players share an id, so keep separate maps.
    private static final Map<Entity, FlightState> CLIENT = Collections.synchronizedMap(new WeakHashMap<>());
    private static final Map<Entity, FlightState> SERVER = Collections.synchronizedMap(new WeakHashMap<>());

    public long lastTick = Long.MIN_VALUE / 4;
    public long thermalScan = Long.MIN_VALUE / 4;
    public float prevYaw;
    public double bank, prevBank, turnRate;
    public double gLoad, gSmooth, aoaDeg, stallMargin, heightAgl = 64.0;
    public double thermal, thermalTarget;
    public boolean stalled;
    public Vec3 right = new Vec3(1, 0, 0);
    public Vec3 up = new Vec3(0, 1, 0);
    public Vec3 wind = Vec3.ZERO;

    private static Map<Entity, FlightState> map(Entity e) {
        return e.level().isClientSide ? CLIENT : SERVER;
    }

    public static FlightState get(Entity e) {
        return map(e).computeIfAbsent(e, k -> new FlightState());
    }

    /** Returns null if the entity never flew. */
    public static FlightState peek(Entity e) {
        return map(e).get(e);
    }

    public boolean isActive(long now) {
        return now - lastTick <= 2;
    }

    public void reset(Entity e) {
        bank = prevBank = turnRate = 0.0;
        gLoad = gSmooth = 1.0;
        aoaDeg = stallMargin = 0.0;
        stalled = false;
        thermal = thermalTarget = 0.0;
        thermalScan = Long.MIN_VALUE / 4;
        prevYaw = e.getYRot();
    }
}
