package com.elytrarealism;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;

/**
 * Replacement for vanilla elytra movement.
 *
 * Model (units: blocks, ticks; gravity = 0.08 b/t^2):
 *  - Your look direction is the wing/body axis, bank is derived from your turn rate.
 *  - Angle of attack = angle between airflow and body axis -> lift/drag with a real stall.
 *  - Sideslip produces a restoring side force (the velocity "weathervanes" into your heading).
 *  - Air is a moving medium: wind, gusts and thermals change the relative airflow.
 */
public final class ElytraPhysics {

    private static final double CL_MAX = 1.25;        // max lift coefficient before stall
    private static final double CD0 = 0.04;           // parasitic drag
    private static final double K_INDUCED = 0.045;    // induced drag factor
    private static final double POST_STALL_CD = 1.3;  // extra drag when stalled
    private static final double SIDE_FORCE = 0.9;     // sideslip restoring force

    private ElytraPhysics() {}

    public static boolean shouldHandle(LivingEntity e) {
        return e instanceof Player
                && e.isFallFlying()
                && !e.isInWater()
                && !e.isInLava()
                && ElytraConfig.COMMON.enabled.get()
                && e.isControlledByLocalInstance();
    }

    private static double gravity(LivingEntity e, Vec3 v) {
        double g = 0.08;
        AttributeInstance ai = e.getAttribute(ForgeMod.ENTITY_GRAVITY.get());
        if (ai != null) g = ai.getValue();
        if (v.y <= 0.0 && e.hasEffect(MobEffects.SLOW_FALLING)) {
            g = Math.min(g, 0.01);
            e.resetFallDistance();
        }
        return Math.max(g, 0.001);
    }

    public static void travel(Player p) {
        ElytraConfig.Common cfg = ElytraConfig.COMMON;
        Level level = p.level();
        long now = level.getGameTime();

        FlightState st = FlightState.get(p);
        if (now - st.lastTick > 3) st.reset(p);
        st.lastTick = now;

        Vec3 v = p.getDeltaMovement();
        double g = gravity(p, v);
        if (v.y > -0.5) p.fallDistance = 1.0F;

        // ---- environment ----
        st.heightAgl = Environment.heightAboveGround(level, p, 64.0);
        Vec3 wind = Environment.wind(level, p, st, now);
        st.wind = wind;
        double rho = Environment.airDensity(p.getY(), cfg.airDensityHeight.get());

        Vec3 rel = v.subtract(wind);                 // velocity relative to the air
        double speed = rel.length();
        double vH = Math.sqrt(rel.x * rel.x + rel.z * rel.z);

        // ---- banking (coordinated turn: tan(bank) = v * turnRate / g) ----
        float yaw = p.getYRot();
        double dYaw = Mth.wrapDegrees(yaw - st.prevYaw);
        st.prevYaw = yaw;
        st.turnRate += (Math.toRadians(dYaw) - st.turnRate) * 0.5;
        double targetBank = cfg.banking.get()
                ? Mth.clamp(Math.atan(vH * st.turnRate / g), -1.3, 1.3) : 0.0;
        st.prevBank = st.bank;
        st.bank += (targetBank - st.bank) * 0.18;

        // ---- body axes ----
        double yawRad = Math.toRadians(yaw);
        Vec3 f = p.getLookAngle();
        Vec3 r0 = new Vec3(-Math.cos(yawRad), 0.0, -Math.sin(yawRad)); // right
        Vec3 u0 = r0.cross(f);                                         // up
        double cb = Math.cos(st.bank), sb = Math.sin(st.bank);
        Vec3 up = u0.scale(cb).add(r0.scale(sb));
        Vec3 right = r0.scale(cb).subtract(u0.scale(sb));
        st.up = up;
        st.right = right;

        // ---- aerodynamics ----
        Vec3 aero = Vec3.ZERO;
        double load = 0.0;
        double alpha = 0.0;
        double stallA = Math.toRadians(cfg.stallAngle.get());

        if (speed > 1.0E-3) {
            Vec3 vh = rel.scale(1.0 / speed);
            double vf = vh.dot(f);
            double vu = vh.dot(up);
            double vr = vh.dot(right);

            alpha = Math.atan2(-vu, vf);             // signed angle of attack
            double aa = Math.abs(alpha);

            double slope = CL_MAX / stallA;
            double pre = Mth.clamp(slope * alpha, -CL_MAX, CL_MAX);
            double post = 1.05 * Math.sin(2.0 * alpha);
            double sigma = smoothstep(stallA, stallA + 0.17, aa); // 0 attached .. 1 stalled
            double cl = (1.0 - sigma) * pre + sigma * post;

            double nearGround = Mth.clamp(1.0 - st.heightAgl / 3.0, 0.0, 1.0); // ground effect
            double kInd = K_INDUCED * (1.0 - 0.5 * nearGround);
            double sa = Math.sin(alpha);
            double cd = CD0 + kInd * pre * pre + sigma * POST_STALL_CD * sa * sa + 0.5 * Math.abs(vr);

            double q = cfg.aeroStrength.get() * rho * speed * speed;
            double maxG = cfg.maxG.get();

            double liftAcc = Mth.clamp(q * cl * (1.0 + 0.15 * nearGround), -0.4 * maxG * g, maxG * g);
            double sideAcc = Mth.clamp(-q * SIDE_FORCE * vr, -0.6 * maxG * g, 0.6 * maxG * g);
            double over = Math.max(0.0, speed / cfg.maxSpeed.get() - 1.0);
            double dragAcc = Math.min(q * cd * (1.0 + 6.0 * over), speed * 0.9);

            aero = perpendicular(up, vh).scale(liftAcc)
                    .add(perpendicular(right, vh).scale(sideAcc))
                    .subtract(vh.scale(dragAcc));
            load = aero.dot(up) / g;                 // G felt along the body "up" axis
        }

        st.gLoad = load;
        st.gSmooth += (load - st.gSmooth) * 0.25;
        st.aoaDeg = Math.toDegrees(alpha);
        st.stallMargin = Math.abs(alpha) / stallA;
        st.stalled = speed > 0.15 && Math.abs(alpha) > stallA;

        // ---- integrate ----
        Vec3 nv = v.add(aero).add(0.0, -g, 0.0);
        double hardMax = cfg.maxSpeed.get() * 1.6;
        double len = nv.length();
        if (len > hardMax) nv = nv.scale(hardMax / len);

        p.setDeltaMovement(nv);
        double hBefore = nv.horizontalDistance();
        p.move(MoverType.SELF, p.getDeltaMovement());

        // ---- impacts / landing (same rules as vanilla, server side) ----
        if (p.horizontalCollision && !level.isClientSide) {
            double hAfter = p.getDeltaMovement().horizontalDistance();
            float dmg = (float) ((hBefore - hAfter) * 10.0 - 3.0) * cfg.impactDamage.get().floatValue();
            if (dmg > 0.0F) {
                p.playSound(dmg > 4.0F ? SoundEvents.PLAYER_BIG_FALL : SoundEvents.PLAYER_SMALL_FALL, 1.0F, 1.0F);
                p.hurt(p.damageSources().flyIntoWall(), dmg);
            }
        }
        if (p.onGround() && !level.isClientSide) {
            p.stopFallFlying();
        }
    }

    /** Component of a perpendicular to dir, normalized (zero if degenerate). */
    private static Vec3 perpendicular(Vec3 a, Vec3 dir) {
        Vec3 r = a.subtract(dir.scale(a.dot(dir)));
        double len = r.length();
        return len > 1.0E-4 ? r.scale(1.0 / len) : Vec3.ZERO;
    }

    private static double smoothstep(double e0, double e1, double x) {
        double t = Mth.clamp((x - e0) / (e1 - e0), 0.0, 1.0);
        return t * t * (3.0 - 2.0 * t);
    }
}
